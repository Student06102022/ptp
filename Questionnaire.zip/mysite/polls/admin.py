from django.contrib import admin

# Register your models here.
# нам нужно сообщить администратору,
# что у Question объектов есть интерфейс администратора.
from django.contrib import admin
from .models import Question

admin.site.register(Question)